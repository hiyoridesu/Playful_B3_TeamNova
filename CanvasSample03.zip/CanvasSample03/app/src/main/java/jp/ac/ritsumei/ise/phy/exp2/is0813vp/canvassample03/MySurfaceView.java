package jp.ac.ritsumei.ise.phy.exp2.is0813vp.canvassample03;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.util.Log;
import android.view.SurfaceHolder;
import android.graphics.Color;
import android.graphics.Paint;
import androidx.annotation.NonNull;


public class MySurfaceView extends SurfaceView implements Runnable,SurfaceHolder.Callback{
    private int layout_width = getWidth();
    private int layout_height = getHeight();

    public MySurfaceView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initialize();
    }

    public MySurfaceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    public MySurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public MySurfaceView(Context context) {
        super(context);
        initialize();
    }




    private SurfaceHolder sHolder;
    private void initialize() {
        sHolder=getHolder();
        sHolder.addCallback(this);
    }


    private Thread thread;
    public float poX = 0;
    public float poY = 0;
    @Override
    public void surfaceCreated(SurfaceHolder holder){
        thread=new Thread(this) ;
        thread.start();
        poX = getWidth()/2;
        poY = getHeight()/2;
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
        thread=null;
    }


    static final long FPS=30;
    static final long FTIME=1000/FPS;

    boolean reverse = true;
    boolean normal = false;

    @Override
    public void run() {
        long loopC=0; //ループ数のカウンタ
        long wTime=0; //次の描画までの待ち時間（ミリ秒）
        long sTime=System.currentTimeMillis(); //開始時の現在時刻
        do {
            loopC++;
            float speed = 10.0f;
            drawCanvas(speed, reverse, normal);
            wTime=(loopC * FTIME)-(System.currentTimeMillis()-sTime);
            if(wTime>0) {
                try {
                    Thread.sleep(wTime);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }while(thread!=null);
    }
    private final static float RADIUS = 50.0f ;


    private void drawCanvas(float steps, boolean Reverse, boolean Normal) {
        Canvas c=sHolder.lockCanvas();
        c.drawColor(Color.YELLOW);
        Paint p=new Paint();
        p.setColor(Color.RED);

        //plus == right,down
        if((Reverse == true) && (Normal == false))//right
        {
            c.drawCircle(poX+steps, poY, RADIUS, p);
            if(poX+steps+RADIUS == c.getWidth())
            {
                reverse = !Reverse;
            }
            poX = poX + steps;
            sHolder.unlockCanvasAndPost(c) ;
        }
        else if ((Reverse == false) && (normal == false))//left
        {
            c.drawCircle(poX-steps, poY, RADIUS, p);
            if(poX-steps-RADIUS == 0)
            {
                reverse = !Reverse;
            }
            poX = poX - steps;
            sHolder.unlockCanvasAndPost(c) ;
        }
        else if ((Reverse == true) && (normal == true))//up
        {
            c.drawCircle(poX, poY-steps, RADIUS, p);
            if( (poY-steps-RADIUS) <= 0.01 )
            {
                reverse = !Reverse;
            }
            poY = poY - steps;
            sHolder.unlockCanvasAndPost(c) ;
        }
        else if ((Reverse == false) && (normal == true))//down
        {
            c.drawCircle(poX, poY+steps, RADIUS, p);
            if( (c.getHeight()) - (poY+steps+RADIUS)<=10 )
            {
                reverse = !Reverse;
            }
            poY = poY + steps;
            sHolder.unlockCanvasAndPost(c) ;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        if(event.getAction() == MotionEvent.ACTION_DOWN){
                normal = !normal;
        }
        return normal;
    }
}

